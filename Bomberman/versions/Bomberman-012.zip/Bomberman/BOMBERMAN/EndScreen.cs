﻿using System;

class EndScreen
{
    public void Run()
    {
        // TO DO
    }
}
