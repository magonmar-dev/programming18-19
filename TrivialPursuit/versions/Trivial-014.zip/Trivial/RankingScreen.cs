﻿using System;

class RankingScreen
{
    // TO DO
}
